# lipSmacking
Software Engineering 1: Restaurant Automation project by Group 2 <br>
Team members:<br>
<ul>
<li>Mahesh Hariharasubramanian 
<li>Shruthi Ravishankar 
<li> Kamalini Chakravorty 
<li> Chaitanya Kulkarni 
<li> Alphy Jose
<li> Peiyao Yang</ul>

  Below are the links to the application hosted on Amazon Web Services: <br>
   LipSmacking Application:<br>
   http://ec2-52-91-34-71.compute-1.amazonaws.com/lipsmacking/  <br>
  
  Login credentials:<br>
  <b>Customer:</b><br>
  username: cust <br>
  password: cust <br>
    <b>Chef:</b><br>
  username: chef <br>
  password: chef <br>
  <b>Waiters: </b><br>
   username: waiter <br>
  password: waiter <br>
  username: waiter1 <br>
  password: waiter <br>
    username: waiter2 <br>
  password: waiter3 <br>
   username: waiter4 <br>
  password: waiter <br>
  <b>Manager:</b><br>
    username: man <br>
  password: man <br>
  
